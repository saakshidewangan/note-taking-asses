require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');

const authRoutes = require('./routes/auth');
const noteRoutes = require('./routes/notes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// API Routes
console.log('authRoutes type:', typeof authRoutes); // should be 'function'
console.log('noteRoutes type:', typeof noteRoutes); // should be 'function'

app.use('/api/auth', authRoutes);
app.use('/api/notes', noteRoutes);

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Fallback for client-side routing (serves login.html by default)
// Fallback for client-side routing (serve login page only for non-API requests)
// Fallback for non-API routes (i.e., client-side routing)
app.get('*', (req, res) => {
  if (req.originalUrl.startsWith('/api/')) {
    return res.status(404).json({ message: 'API route not found' });
  }

  res.sendFile(path.join(__dirname, '../frontend/pages/login.html'));
});


// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
