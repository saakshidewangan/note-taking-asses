const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Example auth route (register/login logic should be handled here)
router.post('/register', async (req, res) => {
  const { firebaseUid, email } = req.body;

  try {
    let user = await User.findOne({ firebaseUid });

    if (!user) {
      user = new User({ firebaseUid, email });
      await user.save();
    }

    res.status(200).json({ success: true, user });
  } catch (err) {
    console.error('Error in /register:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.post('/login', async (req, res) => {
    return res.status(200).json({
        success: true,
        token: 'fake-jwt-token',
        user: { email: req.body.email || 'demo@example.com' }
      });
    });
    
module.exports = router;
